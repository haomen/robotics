function y=proj_pos(x)
y=(x>=0).*x;